from portal.tarefas import criar_app, arquivo_enviado
from portal.integracao import caminho

def preparar(req, pasta):
    pastas = {str(caminho('analisa_certificados', 'pasta_cpf')): 'CPF', str(caminho('analisa_certificados', 'pasta_cnpj')): 'CNPJ'}
    from pathlib import Path
    for p in pastas:
        if not Path(p).is_dir():
            raise ValueError('Uma pasta de certificados está indisponível. Confira config_apps.ini e o acesso do servidor.')
    correcoes = arquivo_enviado(req, 'correcoes', pasta/'correcoes', {'.xlsx'}, required=False)
    return {'pastas': pastas, 'correcoes': correcoes}

app = criar_app(__name__, 'analisa_certificados', 'Inventário de certificados', 'Gera o relatório original por nome, senha no nome do arquivo e data de modificação. A classificação por idade do arquivo não confirma o vencimento real.', '<p class="note">O relatório contém senhas de certificados. Libere este aplicativo somente aos responsáveis.</p>', preparar, 'apps.analisa_certificados.worker')
