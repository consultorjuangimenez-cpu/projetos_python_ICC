import os
import re
import pandas as pd
from datetime import datetime

def extrair_cliente_e_senha(nome_arquivo):
    """
    Analisa o nome do arquivo, limpa sufixos indesejados e extensões duplas,
    e extrai o Cliente e a Senha de forma precisa.
    """
    # Remove qualquer combinação de .pfx e .p12 no final do arquivo (resolve o caso .pfx.p12)
    nome = re.sub(r'(?i)(\.pfx|\.p12)+$', '', nome_arquivo)
    nome = nome.strip()
    
    # ==========================================
    # LIMPEZA PRÉVIA (Remove "sujeiras" do nome)
    # ==========================================
    # 1. Remove cópias do Windows, ex: " (1)", " (2)"
    nome = re.sub(r'\s*\(\d+\)$', '', nome)
    
    # 2. Remove a string literal "(ARROBA)" do final
    nome = re.sub(r'\(ARROBA\)$', '', nome, flags=re.IGNORECASE)
    
    # 3. Remove os sufixos "- CPF" ou "CPF novo" (com ou sem hifens e espaços)
    nome = re.sub(r'[\s\-]*CPF(?:\s+novo)?$', '', nome, flags=re.IGNORECASE)
    
    # 4. Remove marcações de vencimento, ex: "_VENC.16-03-2027"
    nome = re.sub(r'_VENC\..*$', '', nome, flags=re.IGNORECASE)
    
    # 5. Remove um hífen isolado que tenha sobrado no final
    nome = re.sub(r'\s+-$', '', nome)
    
    senha = ""
    cliente = ""
    
    # ==========================================
    # PADRÕES DE EXTRAÇÃO
    # ==========================================
    # 1. Padrão: Nome + espaços + CNPJ/CPF + Data + Senha
    m = re.search(r"^(.*?)\s+\d{11,14}\s+\d{2}-\d{2}-\d{4}\s+(.*)$", nome)
    if m: 
        cliente, senha = m.group(1), m.group(2)
    else:
        # 2. Padrão: Palavra "senha" explícita
        m = re.search(r"^(.*?)(?:[_\s-]*senha[_\s-]+)(.*)$", nome, re.IGNORECASE)
        if m: 
            cliente, senha = m.group(1), m.group(2)
        else:
            # 3. Padrão: Sequência numérica pura no final (após _ ou - ou espaço)
            m = re.search(r"^(.*?)[_\s-]+(\d{3,})$", nome)
            if m:
                cliente, senha = m.group(1), m.group(2)
            else:
                # 4. Padrão Hífen tradicional
                m = re.search(r"^(.*?)\s*-\s*(.*)$", nome)
                if m: 
                    cliente, senha = m.group(1), m.group(2)
                else:
                    # 5. Padrão Underline
                    m = re.search(r"^(.*?)_([^_]+)$", nome)
                    if m and (re.search(r"\d", m.group(2))):
                        cliente, senha = m.group(1), m.group(2)
                    else:
                        # 6. Padrão Espaço
                        m = re.search(r"^(.*?)\s+([^_\s]+)$", nome)
                        if m and (re.search(r"\d", m.group(2))):
                            cliente, senha = m.group(1), m.group(2)
                        else:
                            cliente, senha = nome, "NÃO IDENTIFICADA"
                            
    # ==========================================
    # FORMATAÇÃO FINAL
    # ==========================================
    if senha != "NÃO IDENTIFICADA":
        cliente = cliente.strip(' _-')
        senha_limpa = senha.lstrip('_- ')
        
        # Se a senha final contiver apenas números, ignora traços/underlines no início
        if re.match(r'^\d+$', senha_limpa):
            senha = senha_limpa
        else:
            senha = senha.lstrip('_')
            
    return cliente, senha

def analisar_certificados(pastas_alvo, pasta_destino):

    hoje = datetime.now()
    dados_planilha = []

    for pasta, tipo in pastas_alvo.items():
        if not os.path.exists(pasta):
            print(f"⚠️ Aviso: A pasta '{pasta}' não foi encontrada.")
            continue

        for nome_arquivo in os.listdir(pasta):
            # Ignora arquivos como Thumbs.db
            if "thumbs" in nome_arquivo.lower():
                continue

            caminho_arquivo = os.path.join(pasta, nome_arquivo)
            
            if os.path.isfile(caminho_arquivo):
                nome_cliente, senha_cert = extrair_cliente_e_senha(nome_arquivo)
                
                timestamp_modificacao = os.path.getmtime(caminho_arquivo)
                data_modificacao = datetime.fromtimestamp(timestamp_modificacao)
                dias_passados = (hoje - data_modificacao).days
                
                if dias_passados >= 365:
                    status = "Vencido"
                elif dias_passados <= 200:
                    status = "ATUALIZADO"
                else:
                    status = "PROXIMO VENCIMENTO"
                
                dados_planilha.append({
                    "NOME DO CLIENTE": nome_cliente,
                    "SENHA": senha_cert,
                    "ARQUIVO ORIGINAL": nome_arquivo,
                    "DATA DE MODIFICAÇÃO": data_modificacao.strftime("%d/%m/%Y"),
                    "STATUS": status,
                    "TIPO": tipo
                })

    df = pd.DataFrame(dados_planilha)
    
    if not os.path.exists(pasta_destino):
        os.makedirs(pasta_destino)
        
    caminho_planilha = os.path.join(pasta_destino, "Relatorio_Certificados_2.xlsx")

    if not df.empty:
        df.to_excel(caminho_planilha, index=False)
        print(f"✅ Processo concluído! Planilha gerada em:\n{caminho_planilha}")
    else:
        print("❌ Nenhum arquivo válido encontrado.")

