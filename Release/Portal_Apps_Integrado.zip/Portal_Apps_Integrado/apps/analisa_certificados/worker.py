import json, sys
from pathlib import Path
from .processamento import analisar_certificados
if __name__ == '__main__':
    pasta = Path(sys.argv[1])
    params = json.loads((pasta/'parametros.json').read_text(encoding='utf-8'))
    analisar_certificados(params['pastas'], str(pasta/'saida'))
    msg = 'Inventário concluído.' if list((pasta/'saida').glob('*.xlsx')) else 'Nenhum arquivo encontrado nas pastas configuradas.'
    (pasta/'resultado.json').write_text(json.dumps({'mensagem':msg}), encoding='utf-8')
