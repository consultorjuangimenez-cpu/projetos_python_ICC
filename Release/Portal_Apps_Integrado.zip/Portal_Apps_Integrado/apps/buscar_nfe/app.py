import re
from datetime import datetime
from portal.tarefas import criar_app
from portal.integracao import caminho, CONFIG_APPS


def preparar(req, pasta):
    documento = re.sub(r'\D', '', req.form.get('documento',''))
    if len(documento) not in (11,14):
        raise ValueError('Informe um CPF ou CNPJ com 11 ou 14 dígitos.')
    tipo = req.form.get('tipo','Entrada')
    if tipo not in ('Entrada','Saida','Ambas'):
        raise ValueError('Tipo de movimentação inválido.')
    ano = req.form.get('ano','').strip()
    if not re.fullmatch(r'20[0-9]{2}',ano):
        raise ValueError('Informe um ano de quatro dígitos.')
    texto = req.form.get('chaves','').strip()
    partes = re.split(r'[;,\r\n]+',texto)
    chaves = list(dict.fromkeys(re.sub(r'\D','',p) for p in partes if p.strip()))
    if not chaves or any(len(c)!=44 for c in chaves):
        raise ValueError('Cada chave deve conter 44 dígitos. Separe por linha, vírgula ou ponto e vírgula.')
    if len(chaves)>1000:
        raise ValueError('Limite de 1.000 chaves por pesquisa.')
    raiz = caminho('sieg','pasta_xmls')
    if not raiz.is_dir():
        raise ValueError('A pasta de XMLs não está disponível. Confira config_apps.ini e o acesso do servidor.')
    return {'documento':documento,'tipo':tipo,'ano':ano,'chaves':chaves,'raiz':str(raiz)}

ano = CONFIG_APPS.get('sieg','ano',fallback=str(datetime.now().year))
# Valor de configuração validado antes de entrar no template.
if not re.fullmatch(r'20[0-9]{2}',ano): ano=str(datetime.now().year)
campos = '''<label>CPF/CNPJ</label><input name="documento" required>
<label>Movimentação</label><select name="tipo"><option>Entrada</option><option value="Saida">Saída</option><option>Ambas</option></select>
<label>Ano</label><input name="ano" value="'''+ano+'''" pattern="20[0-9]{2}" required>
<label>Chaves de acesso</label><textarea name="chaves" rows="7" required></textarea>'''
app = criar_app(__name__, 'buscar_nfe', 'Buscar NF-es',
    'Pesquisa os XMLs e PDFs correspondentes nas pastas locais do HUB SIEG. A chave dentro do XML é conferida antes do download.',
    campos, preparar, 'apps.buscar_nfe.worker')
