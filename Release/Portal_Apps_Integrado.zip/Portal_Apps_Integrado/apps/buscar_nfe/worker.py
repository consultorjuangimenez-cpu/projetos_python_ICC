import json
import os
import re
import sys
import zipfile
from pathlib import Path
from defusedxml import ElementTree as ET


def extrair_chave_do_xml(path):
    try:
        if path.stat().st_size > 20 * 1024 * 1024:
            return None
        tree = ET.parse(path)
        for node in tree.iter():
            if node.tag.split('}')[-1] == 'infNFe':
                value = node.attrib.get('Id','')
                if re.fullmatch(r'NFe[0-9]{44}',value): return value[3:]
        for node in tree.iter():
            if node.tag.split('}')[-1] == 'chNFe' and re.fullmatch(r'[0-9]{44}',node.text or ''):
                return node.text
    except Exception:
        return None
    return None


def buscar(params):
    raiz = Path(params['raiz']).resolve(strict=True)
    doc = (raiz/params['documento']).resolve(strict=True)
    if not doc.is_relative_to(raiz) or not doc.is_dir():
        raise ValueError('Pasta de CPF/CNPJ indisponível.')
    chaves = set(params['chaves'])
    numeros = {str(int(c[25:34])) for c in chaves}
    tipos = {'entrada','saida'} if params['tipo']=='Ambas' else {params['tipo'].lower()}
    melhores = {}
    recusados = 0
    for folder, dirs, files in os.walk(doc, followlinks=False):
        base = Path(folder)
        dirs[:] = [d for d in dirs if (base/d).resolve().is_relative_to(doc) and not (base/d).is_symlink()]
        partes = {p.lower() for p in base.relative_to(doc).parts}
        if params['ano'] not in partes or not partes.intersection(tipos): continue
        pdfs = {Path(n).stem.lower(): base/n for n in files if Path(n).suffix.lower()=='.pdf'}
        for name in sorted(files):
            path=base/name
            if path.suffix.lower()!='.xml': continue
            stem=path.stem
            curto=str(int(stem)) if stem.isdigit() and len(stem)<=12 else stem
            if stem not in chaves and curto not in numeros: continue
            resolved=path.resolve()
            if not resolved.is_relative_to(doc): continue
            chave=extrair_chave_do_xml(resolved)
            if chave not in chaves:
                recusados += 1
                continue
            pdf=pdfs.get(stem.lower())
            if pdf and not pdf.resolve().is_relative_to(doc): pdf=None
            mtime=resolved.stat().st_mtime_ns
            if chave not in melhores or mtime>melhores[chave]['mtime']:
                melhores[chave]={'xml':resolved,'pdf':pdf,'mtime':mtime}
    return melhores, recusados


def executar(pasta, params):
    encontrados, recusados = buscar(params)
    if encontrados:
        with zipfile.ZipFile(pasta/'saida/Notas.zip','w',zipfile.ZIP_DEFLATED) as z:
            for chave, arquivos in encontrados.items():
                z.write(arquivos['xml'],chave+'.xml')
                if arquivos['pdf']: z.write(arquivos['pdf'],chave+'.pdf')
    faltantes=[c for c in params['chaves'] if c not in encontrados]
    resumo=f'{len(encontrados)} XML(s) localizado(s); {len(faltantes)} chave(s) não localizada(s).'
    texto=resumo+f'\nCandidatos recusados por chave ausente/diferente: {recusados}.\n'
    if faltantes: texto+='\nChaves não localizadas:\n'+'\n'.join(faltantes)
    (pasta/'saida/Resumo.txt').write_text(texto,encoding='utf-8')
    return resumo

if __name__=='__main__':
    pasta=Path(sys.argv[1])
    params=json.loads((pasta/'parametros.json').read_text(encoding='utf-8'))
    mensagem=executar(pasta,params)
    (pasta/'resultado.json').write_text(json.dumps({'mensagem':mensagem},ensure_ascii=False),encoding='utf-8')
