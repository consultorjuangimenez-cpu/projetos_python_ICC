# -*- coding: utf-8 -*-
"""Aplicação web para localizar e baixar PDFs pelo CNPJ contido no documento.

Histórico:
    1.0.0 - Busca textual por CNPJ, índice incremental e download em ZIP.
"""

import secrets
import tempfile
import threading
import time
import zipfile
from datetime import datetime, timedelta
from pathlib import Path

from flask import Flask, abort, render_template, request, send_file, g

from .src.cnpj import CNPJInvalido, formatar_cnpj, validar_cnpj
from .src.configuracao import carregar_configuracao, resolver_caminho
from .src.indice_pdf import DocumentoPDF, buscar_pdfs_por_cnpj
from .src.logs import configurar_logger
from .src.zip_utils import nome_zip_disponivel
from .versao import __version__


BASE_DIR = Path(__file__).resolve().parent
CONFIG = carregar_configuracao(BASE_DIR / "config.json")
from portal.integracao import caminho
from portal.settings import BASE_DIR as PORTAL_DIR
PASTA_DOCUMENTOS = caminho("pdf_cnpj", "pasta_documentos", CONFIG["pastas"]["documentos"])
CAMINHO_INDICE = PORTAL_DIR / "dados/apps/buscar_pdf_cnpj/indice_pdfs.sqlite3"
PASTA_LOGS = PORTAL_DIR / "logs/buscar_pdf_cnpj"
PASTA_LOGS.mkdir(parents=True, exist_ok=True)
CAMINHO_INDICE.parent.mkdir(parents=True, exist_ok=True)

LOGGER = configurar_logger(
    nome=CONFIG["projeto"]["slug"],
    pasta_logs=PASTA_LOGS,
    nivel=CONFIG["logs"]["nivel"],
    dias_retencao=CONFIG["logs"]["dias_retencao"],
)

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 1 * 1024 * 1024

_indice_lock = threading.Lock()
_resultados_lock = threading.Lock()
_resultados: dict[str, dict] = {}


def _limpar_resultados_expirados() -> None:
    limite = datetime.now() - timedelta(
        minutes=CONFIG["busca"]["resultado_expira_minutos"]
    )
    with _resultados_lock:
        expirados = [
            token
            for token, resultado in _resultados.items()
            if resultado["criado_em"] < limite
        ]
        for token in expirados:
            _resultados.pop(token, None)


def _guardar_resultado(cnpj: str, documentos: list[DocumentoPDF]) -> str:
    _limpar_resultados_expirados()
    token = secrets.token_urlsafe(24)
    with _resultados_lock:
        _resultados[token] = {
            "criado_em": datetime.now(),
            "usuario_id": g.usuario["id"],
            "cnpj": cnpj,
            "documentos": documentos,
        }
    return token


def _obter_resultado(token: str) -> dict | None:
    _limpar_resultados_expirados()
    with _resultados_lock:
        resultado = _resultados.get(token)
        return resultado if resultado and resultado["usuario_id"] == g.usuario["id"] else None


def _tamanho_legivel(tamanho: int) -> str:
    valor = float(tamanho)
    for unidade in ("B", "KB", "MB", "GB"):
        if valor < 1024 or unidade == "GB":
            return f"{valor:.0f} {unidade}" if unidade == "B" else f"{valor:.1f} {unidade}"
        valor /= 1024
    return f"{tamanho} B"


def _documento_dentro_da_raiz(caminho: Path) -> bool:
    try:
        raiz_real = PASTA_DOCUMENTOS.resolve(strict=True)
        caminho_real = caminho.resolve(strict=True)
        return caminho_real.is_file() and caminho_real.is_relative_to(raiz_real)
    except (OSError, RuntimeError):
        return False


@app.get("/")
def pagina_inicial():
    return render_template(
        "index.html",
        versao=__version__,
        pasta_documentos=str(PASTA_DOCUMENTOS),
    )


@app.post("/buscar")
def buscar():
    valor_informado = request.form.get("cnpj", "")

    try:
        cnpj = validar_cnpj(valor_informado)
    except CNPJInvalido as exc:
        return render_template(
            "index.html",
            versao=__version__,
            pasta_documentos=str(PASTA_DOCUMENTOS),
            erro=str(exc),
            cnpj_digitado=valor_informado,
        ), 400

    if not PASTA_DOCUMENTOS.is_dir():
        mensagem = f"A pasta de documentos não está disponível: {PASTA_DOCUMENTOS}"
        LOGGER.error(mensagem)
        return render_template(
            "index.html",
            versao=__version__,
            pasta_documentos=str(PASTA_DOCUMENTOS),
            erro=mensagem,
            cnpj_digitado=formatar_cnpj(cnpj),
        ), 503

    inicio = time.monotonic()
    try:
        with _indice_lock:
            documentos, estatisticas = buscar_pdfs_por_cnpj(
                raiz=PASTA_DOCUMENTOS,
                caminho_indice=CAMINHO_INDICE,
                cnpj=cnpj,
                logger=LOGGER,
            )
    except Exception as exc:
        LOGGER.exception("Falha na busca do CNPJ %s: %s", cnpj, exc)
        return render_template(
            "index.html",
            versao=__version__,
            pasta_documentos=str(PASTA_DOCUMENTOS),
            erro="Não foi possível concluir a busca. Consulte o log para detalhes.",
            cnpj_digitado=formatar_cnpj(cnpj),
        ), 500

    token = _guardar_resultado(cnpj, documentos)
    duracao = time.monotonic() - inicio
    LOGGER.info(
        "Busca concluída | cnpj=%s | encontrados=%s | total_pdfs=%s | "
        "lidos=%s | reaproveitados=%s | sem_texto=%s | erros=%s | segundos=%.2f",
        cnpj,
        len(documentos),
        estatisticas.total_pdfs,
        estatisticas.lidos,
        estatisticas.reaproveitados,
        estatisticas.sem_texto,
        estatisticas.erros,
        duracao,
    )

    itens = [
        {
            "id": indice,
            "nome": documento.caminho.name,
            "caminho_relativo": documento.caminho_relativo,
            "tamanho": _tamanho_legivel(documento.tamanho),
        }
        for indice, documento in enumerate(documentos)
    ]

    return render_template(
        "index.html",
        versao=__version__,
        pasta_documentos=str(PASTA_DOCUMENTOS),
        cnpj_digitado=formatar_cnpj(cnpj),
        cnpj_encontrado=formatar_cnpj(cnpj),
        resultados=itens,
        token=token,
        estatisticas=estatisticas,
        duracao=duracao,
    )


@app.post("/baixar")
def baixar():
    token = request.form.get("token", "")
    resultado = _obter_resultado(token)
    if not resultado:
        abort(410, description="A pesquisa expirou. Faça uma nova busca.")

    ids_recebidos = request.form.getlist("arquivos")
    if not ids_recebidos:
        abort(400, description="Selecione pelo menos um PDF.")

    limite = CONFIG["busca"]["maximo_arquivos_por_zip"]
    if len(ids_recebidos) > limite:
        abort(400, description=f"O limite por download é de {limite} arquivos.")

    documentos: list[DocumentoPDF] = resultado["documentos"]
    selecionados: list[DocumentoPDF] = []
    ids_unicos: set[int] = set()

    for valor in ids_recebidos:
        try:
            indice = int(valor)
        except ValueError:
            abort(400, description="Seleção de arquivo inválida.")
        if indice in ids_unicos or not 0 <= indice < len(documentos):
            continue
        ids_unicos.add(indice)
        documento = documentos[indice]
        if _documento_dentro_da_raiz(documento.caminho):
            selecionados.append(documento)
        else:
            LOGGER.warning("Arquivo indisponível ou fora da raiz: %s", documento.caminho)

    if not selecionados:
        abort(404, description="Nenhum dos arquivos selecionados está disponível.")

    arquivo_zip = tempfile.SpooledTemporaryFile(
        max_size=CONFIG["busca"]["memoria_zip_mb"] * 1024 * 1024,
        mode="w+b",
    )
    nomes_usados: set[str] = set()
    with zipfile.ZipFile(arquivo_zip, "w", compression=zipfile.ZIP_DEFLATED) as zip_saida:
        for documento in selecionados:
            nome_no_zip = nome_zip_disponivel(documento.caminho.name, nomes_usados)
            zip_saida.write(documento.caminho, arcname=nome_no_zip)

    arquivo_zip.seek(0)
    cnpj = resultado["cnpj"]
    LOGGER.info("ZIP gerado | cnpj=%s | arquivos=%s", cnpj, len(selecionados))

    return send_file(
        arquivo_zip,
        as_attachment=True,
        download_name=f"PDFs_CNPJ_{cnpj}.zip",
        mimetype="application/zip",
        max_age=0,
    )


@app.errorhandler(400)
@app.errorhandler(404)
@app.errorhandler(410)
def erro_solicitacao(exc):
    return render_template(
        "index.html",
        versao=__version__,
        pasta_documentos=str(PASTA_DOCUMENTOS),
        erro=getattr(exc, "description", "Solicitação inválida."),
    ), exc.code


