"""Índice incremental do texto dos PDFs usando SQLite."""

import logging
import re
import sqlite3
import uuid
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path

from pypdf import PdfReader


@dataclass(frozen=True)
class DocumentoPDF:
    caminho: Path
    caminho_relativo: str
    tamanho: int


@dataclass
class EstatisticasIndice:
    total_pdfs: int = 0
    lidos: int = 0
    reaproveitados: int = 0
    sem_texto: int = 0
    erros: int = 0


def _criar_tabela(conexao: sqlite3.Connection) -> None:
    conexao.execute(
        """
        CREATE TABLE IF NOT EXISTS pdfs (
            caminho TEXT PRIMARY KEY,
            caminho_relativo TEXT NOT NULL,
            tamanho INTEGER NOT NULL,
            mtime_ns INTEGER NOT NULL,
            conteudo_numerico TEXT NOT NULL,
            status TEXT NOT NULL,
            erro TEXT,
            ultimo_scan TEXT NOT NULL,
            atualizado_em TEXT NOT NULL
        )
        """
    )
    conexao.execute("CREATE INDEX IF NOT EXISTS idx_pdfs_scan ON pdfs (ultimo_scan)")


def _listar_pdfs(raiz: Path) -> list[Path]:
    return sorted(
        caminho
        for caminho in raiz.rglob("*")
        if caminho.is_file() and caminho.suffix.lower() == ".pdf"
        and caminho.resolve().is_relative_to(raiz.resolve())
    )


def _extrair_conteudo_numerico(caminho: Path) -> tuple[str, str, str | None]:
    try:
        leitor = PdfReader(str(caminho), strict=False)
        if leitor.is_encrypted:
            resultado = leitor.decrypt("")
            if resultado == 0:
                return "", "erro", "PDF protegido por senha"

        textos = []
        for pagina in leitor.pages:
            texto = pagina.extract_text() or ""
            if texto:
                textos.append(texto)

        conteudo_numerico = re.sub(r"\D", "", " ".join(textos))
        if not conteudo_numerico:
            return "", "sem_texto", "PDF sem texto extraível; pode ser escaneado"
        return conteudo_numerico, "ok", None
    except Exception as exc:
        return "", "erro", f"{type(exc).__name__}: {exc}"


def buscar_pdfs_por_cnpj(
    raiz: Path,
    caminho_indice: Path,
    cnpj: str,
    logger: logging.Logger,
) -> tuple[list[DocumentoPDF], EstatisticasIndice]:
    estatisticas = EstatisticasIndice()
    scan_id = uuid.uuid4().hex
    momento = datetime.now().isoformat(timespec="seconds")
    arquivos = _listar_pdfs(raiz)
    estatisticas.total_pdfs = len(arquivos)
    encontrados: list[DocumentoPDF] = []

    caminho_indice.parent.mkdir(parents=True, exist_ok=True)
    with sqlite3.connect(caminho_indice, timeout=30) as conexao:
        _criar_tabela(conexao)

        for indice, caminho in enumerate(arquivos, start=1):
            try:
                dados = caminho.stat()
                caminho_texto = str(caminho.resolve())
                relativo = str(caminho.relative_to(raiz))
                registro = conexao.execute(
                    """
                    SELECT tamanho, mtime_ns, conteudo_numerico, status
                    FROM pdfs WHERE caminho = ?
                    """,
                    (caminho_texto,),
                ).fetchone()

                if registro and registro[0] == dados.st_size and registro[1] == dados.st_mtime_ns:
                    conteudo_numerico, status = registro[2], registro[3]
                    estatisticas.reaproveitados += 1
                    conexao.execute(
                        "UPDATE pdfs SET ultimo_scan = ? WHERE caminho = ?",
                        (scan_id, caminho_texto),
                    )
                else:
                    conteudo_numerico, status, erro = _extrair_conteudo_numerico(caminho)
                    estatisticas.lidos += 1
                    conexao.execute(
                        """
                        INSERT INTO pdfs (
                            caminho, caminho_relativo, tamanho, mtime_ns,
                            conteudo_numerico, status, erro, ultimo_scan, atualizado_em
                        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                        ON CONFLICT(caminho) DO UPDATE SET
                            caminho_relativo = excluded.caminho_relativo,
                            tamanho = excluded.tamanho,
                            mtime_ns = excluded.mtime_ns,
                            conteudo_numerico = excluded.conteudo_numerico,
                            status = excluded.status,
                            erro = excluded.erro,
                            ultimo_scan = excluded.ultimo_scan,
                            atualizado_em = excluded.atualizado_em
                        """,
                        (
                            caminho_texto,
                            relativo,
                            dados.st_size,
                            dados.st_mtime_ns,
                            conteudo_numerico,
                            status,
                            erro,
                            scan_id,
                            momento,
                        ),
                    )
                    if status != "ok":
                        logger.warning("PDF não indexado | arquivo=%s | motivo=%s", caminho, erro)

                if status == "sem_texto":
                    estatisticas.sem_texto += 1
                elif status == "erro":
                    estatisticas.erros += 1

                if status == "ok" and cnpj in conteudo_numerico:
                    encontrados.append(
                        DocumentoPDF(
                            caminho=caminho,
                            caminho_relativo=relativo,
                            tamanho=dados.st_size,
                        )
                    )

                if indice % 100 == 0:
                    conexao.commit()
                    logger.info("Indexação em andamento | %s de %s PDFs", indice, len(arquivos))
            except OSError as exc:
                estatisticas.erros += 1
                logger.warning("Não foi possível acessar o PDF %s: %s", caminho, exc)

        conexao.execute("DELETE FROM pdfs WHERE ultimo_scan <> ?", (scan_id,))
        conexao.commit()

    return encontrados, estatisticas
