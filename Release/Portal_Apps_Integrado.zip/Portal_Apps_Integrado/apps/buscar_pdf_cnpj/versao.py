"""Versão oficial do projeto. Altere somente neste arquivo."""

__version__ = "1.0.0"
