# Validação da entrega

Data: 15/09/2026. Resultado: **50 testes automatizados aprovados, sem falhas**.

Ambiente executado: Linux, Python 3.12.14, Flask 3.1.3, Waitress 3.0.2 e tzdata 2026.4. Testes de integração utilizaram os arquivos reais de autenticação, usuários e catálogo do `Portal_Apps.zip` enviado em 10/09/2026, sem carregar dados ou credenciais de produção.

## Cobertura

| Área | Casos conferidos |
|---|---|
| Calendário | Dia 31 sem desvio nos meses seguintes, 29/02, dias da semana, dia mensal personalizado, intervalo de 15 dias, limites, término, horário de verão e salto de vinte anos |
| Validação | Campos obrigatórios, data/horário no passado, injeção de cabeçalhos no e-mail, links inseguros, UNC, múltiplos links e limites inválidos |
| Concorrência | 16 solicitações concorrentes e 16 reservas concorrentes geram uma única ocorrência/reserva; lock do processo exclui outra abertura |
| Retomada | Reinício não duplica ocorrência concluída; interrupção em SENDING exige conferência; fila persiste sem senha SMTP |
| Recorrência | Avanço mensal, envio único de pendência após parada, contagem de datas puladas e limite sem consumo por envio manual |
| Envio manual | Chave idempotente, confirmação, reapresentação do formulário sem duplicação e preservação da próxima execução |
| Erros | Até três tentativas temporárias; recusa definitiva; falha durante DATA sem reenvio automático; sucesso manual não esconde erro agendado |
| SMTP | HTML escapado, parte texto, Message-ID, STARTTLS, erro de autenticação/destinatário, falha de rede e erro de fechamento após aceite |
| Histórico | Preservação após cancelamento, conteúdo histórico imutável, resolução explícita e teste de e-mail registrado |
| Permissões | Login e CSRF reais do portal, bloqueio por rota, isolamento do proprietário, teste SMTP exclusivo para administrador e falha fechada sem portal |
| Telas HTTP | Dashboard, formulário, detalhe, edição, confirmação, histórico e teste com o prefixo de montagem correto |
| Instalação | Inclusão sem alterar outros cadastros, preservação do código central/banco/configuração, reinstalação idempotente e recusa de rota conflitante |

Os 12 arquivos Python passaram por análise de sintaxe. Os quatro arquivos PowerShell passaram por análise sintática com a gramática PowerShell do Tree-sitter. Essa verificação não equivale a executar os comandos nativos do Windows.

## Limites da verificação

- Nenhuma mensagem foi transmitida a destinatários reais. Os testes SMTP usam simuladores de respostas e falhas.
- O Agendador de Tarefas, DPAPI, permissões Windows e autenticação na KingHost dependem do servidor de destino e precisam ser validados durante a instalação.
- A tentativa de inspeção visual em navegador foi bloqueada pelo ambiente de testes ao abrir o endereço local. Os templates renderizados, rotas e submissões foram testados por HTTP, mas não houve validação visual completa no navegador.
- A integração foi verificada com a versão disponibilizada em 10/09. O instalador preserva os arquivos atuais do portal e interrompe caso não reconheça sua interface de acesso/catálogo.

## Critérios de aceite no servidor

1. Entrar como administrador, abrir o aplicativo e cadastrar uma tarefa para uma caixa de teste com horário alguns minutos à frente.
2. Conferir “Agendador ativo” e executar “Teste de e-mail”. Confirmar ENVIADO no histórico e recebimento na caixa de entrada.
3. Fechar o navegador e confirmar que a tarefa programada é enviada no horário previsto, considerando o intervalo de consulta de 15 segundos, a fila e a resposta do provedor.
4. Criar uma tarefa recorrente e conferir a próxima data após o primeiro aceite.
5. Executar “Enviar agora” e confirmar que a programação futura permanece igual.
6. Entrar com um usuário sem permissão e confirmar que o aplicativo permanece bloqueado. Usuários comuns devem ver somente as tarefas que criaram.
7. Em uma janela de manutenção, reiniciar o servidor, confirmar a retomada do agendador sem login interativo e conferir os registros pendentes.

## Reexecutar os testes

Na pasta extraída do pacote, use o Python do portal. Em PowerShell:

```powershell
$env:LEMBRETES_PORTAL_REFERENCIA = 'C:\C\Projetos_Phyton\Portal_Apps'
& 'C:\C\Projetos_Phyton\Portal_Apps\.venv\Scripts\python.exe' -m unittest discover -s testes_lembretes -v
```

Os testes criam bancos, usuários e instalações fictícias somente em diretórios temporários. A referência do portal é lida para utilizar os módulos reais. O código central e os dados do portal de referência não são alterados.
